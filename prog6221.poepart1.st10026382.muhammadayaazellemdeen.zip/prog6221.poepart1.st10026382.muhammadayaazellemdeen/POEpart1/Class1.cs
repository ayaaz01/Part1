﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Diagnostics.SymbolStore;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

public class POEpart1
{
    public static void Main()
    {
        firstMain();
        secondMain();
    }
    public static void firstMain()
    {
            Console.WriteLine("how many ingredients are required for this recipe?");

            int ingredients = Convert.ToInt32(Console.ReadLine());
            int ing = ingredients;
        
            string[] IngName = new string[ing];
            int[] quantity = new int[ing];
            string[] unit = new string[ing];
            int[] table = new int[ing];

        for (int i = 0; i < ing; i++)
        {
            Console.WriteLine("--------------------------------------------------------------------------------------------------");
            Console.WriteLine("For ingredient number: " + (i+1));

            Console.WriteLine("Enter the name of this ingredient: ");
            IngName[i] = Console.ReadLine();
            Console.WriteLine("--------------------------------------------------------------------------------------------------");


            //Console.WriteLine("What is the unit of measurement?");
            //unit[i] = Console.ReadLine();

            Console.WriteLine("Please select unit of measurment for this ingredient: ");
            Console.WriteLine("1. Tsp");
            Console.WriteLine("2. Tbsp");
            Console.WriteLine("3. Cup");
            Console.WriteLine("4. g");
            Console.WriteLine("5. Kg");
            Console.WriteLine("6. mL");
            Console.WriteLine("7. l");
            table[i] = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("--------------------------------------------------------------------------------------------------");

            Console.WriteLine("What is the quantity needed for this Ingredient?");
            quantity[i] = Convert.ToInt32(Console.ReadLine());

        }
        for (int i = 0; i < ing; i++)
        {
            if (table[i] == 1)
            {
                unit[i] = "Tsp";
            }
            if (table[i] == 2)
            {
                unit[i] = "Tbsp";
            }
            if (table[i] == 3)
            {
                unit[i] = "Cup";
            }
            if (table[i] == 4)
            {
                unit[i] = "g";
            }
            if (table[i] == 5)
            {
                unit[i] = "Kg";
            }
            if (table[i] == 6) 
            {
                unit[i] = "mL";
            }
            if (table[i] == 7)
            {
                unit[i] = "l";
            }
        }

            Console.WriteLine("--------------------------------------------------------------------------------------------------");
            Console.WriteLine("How many steps are required for this recipe?");
            int steps = Convert.ToInt32(Console.ReadLine());
            string[] stepdes = new string[steps];
        
        for (int i = 0; i < steps; i++)
        {
            Console.WriteLine("--------------------------------------------------------------------------------------------------");
            Console.WriteLine("Please enter step number: " + (i + 1));
            stepdes[i] = Console.ReadLine();
        }

            Console.WriteLine("--------------------------------------------------------------------------------------------------");
            Console.WriteLine("LIST OF INGREDIENTS: ");

        for (int i = 0; i < ing; i++)
        {
            Console.WriteLine((i + 1)+ "." + IngName[i] + ": " + quantity[i] +" "+ unit[i] );
            
        }

            Console.WriteLine("--------------------------------------------------------------------------------------------------");
            Console.WriteLine("LIST OF STEPS: ");

        for (int i = 0; i < steps; i++)
        {
            Console.WriteLine((i+1) + "." + stepdes[i]);
        }

            Console.WriteLine("--------------------------------------------------------------------------------------------------");
            Console.WriteLine("would you like the quantities be scaled by a factor of 0.5 (half), 2 (double), 3 (triple) - (yes/no) ");
            String yon = Console.ReadLine();
        
        
        double[] quantity2 = new double[ing];

        while (yon != "yes" && yon != "no")
        {
            Console.WriteLine("Invalid input. Please enter either 'yes' or 'no'.");
            yon = Console.ReadLine();
        }

        if (yon == "yes")
        {
            Console.WriteLine("please enter the factor at which you wish to multiply the quantities");

            double fact = Convert.ToDouble(Console.ReadLine());


            for (int i = 0; i < ing; i++)
            {
                quantity2[i] = quantity[i] * fact;
            }

            Console.WriteLine("--------------------------------------------------------------------------------------------------");
            Console.WriteLine("LIST OF INGREDIENTS: ");

            for (int i = 0; i < ing; i++)
            {
                Console.WriteLine((i + 1) + "." + IngName[i] + ": " + quantity2[i] + " " + unit[i]);
            }

            Console.WriteLine("--------------------------------------------------------------------------------------------------");
            Console.WriteLine("LIST OF STEPS: ");

            for (int i = 0; i < steps; i++)
            {
                Console.WriteLine((i + 1) + "." + stepdes[i]);
            }

        }

        Console.WriteLine("--------------------------------------------------------------------------------------------------");

        if (yon == "no")
        {
            Console.WriteLine("LIST OF INGREDIENTS: ");

            for (int i = 0; i < ing; i++)
            {
                Console.WriteLine((i + 1) + "." + IngName[i] + ": " + quantity[i] + " " + unit[i]);

            }

            Console.WriteLine("--------------------------------------------------------------------------------------------------");
            Console.WriteLine("LIST OF STEPS: ");

            for (int i = 0; i < steps; i++)
            {
                Console.WriteLine((i + 1) + "." + stepdes[i]);
            }
        }
        
        bool validOriginal = false;

        if (yon == "yes")
        {
            while (!validOriginal)
            {
                Console.WriteLine("Would you like to reset the quantities back to the original? - (yes/no)");
                string original = Console.ReadLine();

                if (original == "yes")
                {
                    Console.WriteLine("--------------------------------------------------------------------------------------------------");
                    Console.WriteLine("LIST OF INGREDIENTS: ");

                    for (int i = 0; i < ing; i++)
                    {
                        Console.WriteLine((i + 1) + "." + IngName[i] + ": " + quantity[i] + " " + unit[i]);
                    }

                    Console.WriteLine("--------------------------------------------------------------------------------------------------");
                    Console.WriteLine("LIST OF STEPS: ");

                    for (int i = 0; i < steps; i++)
                    {
                        Console.WriteLine((i + 1) + "." + stepdes[i]);
                    }

                    validOriginal = true;
                }
                else if (original == "no")
                {
                    Console.WriteLine("--------------------------------------------------------------------------------------------------");
                    Console.WriteLine("LIST OF INGREDIENTS: ");

                    for (int i = 0; i < ing; i++)
                    {
                        Console.WriteLine((i + 1) + "." + IngName[i] + ": " + quantity2[i] + " " + unit[i]);
                    }

                    Console.WriteLine("--------------------------------------------------------------------------------------------------");
                    Console.WriteLine("LIST OF STEPS: ");

                    for (int i = 0; i < steps; i++)
                    {
                        Console.WriteLine((i + 1) + "." + stepdes[i]);
                    }

                    validOriginal = true;
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter either 'yes' or 'no'.");
                }
            }
        }

        Console.WriteLine("--------------------------------------------------------------------------------------------------");
    }
    public static void secondMain()
    {

        bool checker = false;

        while (!checker)
        {
            Console.WriteLine("Would you like to reset and enter a new recipe? - (yes/no)");
            string x = Console.ReadLine();

            if (x == "yes")
            {
                Console.WriteLine("--------------------------------------------------------------------------------------------------");
                Main();
                checker = true;
            }
            else if (x == "no")
            {
                Console.WriteLine("--------------------------------------------------------------------------------------------------");
                Console.WriteLine("THANK YOU! HAVE A GREAT DAY AHEAD ;)");
                checker = true;
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter either 'yes' or 'no'.");
            }
        }
        }
}